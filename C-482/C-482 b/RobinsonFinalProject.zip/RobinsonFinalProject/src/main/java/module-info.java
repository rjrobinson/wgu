module com.example.robinsonfinalproject {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.robinsonfinalproject to javafx.fxml;
    exports com.example.robinsonfinalproject;
    exports controllers;
    opens controllers to javafx.fxml;

    exports models;
    opens models to javafx.fxml;

    exports models.parts;
    opens models.parts to javafx.fxml;

}