package controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;
import models.Inventory;
import models.Part;
import models.parts.InHouse;
import models.parts.Outsourced;
import models.validators.Validators;
import utilities.SceneHelper;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * The Parts controller.
 * {PartsControlle}r handles actions relating to the Creation and modification of {Parts}
 */
public class PartsController implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resourceBundle) {
        Part selected_part = MainController.part_to_update();

        try {
            if (selected_part instanceof InHouse) {
                in_house_radio_button.setSelected(true);
                part_type_name_label.setText("Machine ID");
                part_id_name_text.setText(String.valueOf(((InHouse) selected_part).getMachineId()));
            }

            if (selected_part instanceof Outsourced) {
                outsourced_radio_button.setSelected(true);
                part_type_name_label.setText("Company Name");
                part_id_name_text.setText(((Outsourced) selected_part).getCompanyName());
            }

            part_id_text.setText(String.valueOf(selected_part.getId()));
            part_name_text.setText(selected_part.getName());
            part_inventory_text.setText(String.valueOf(selected_part.getStock()));
            part_price_text.setText(String.valueOf(selected_part.getPrice()));
            part_max_text.setText(String.valueOf(selected_part.getMax()));
            part_min_text.setText(String.valueOf(selected_part.getMin()));
        } catch (NullPointerException e) {
            System.out.println("No part selected");
            System.out.println("creating a new part . . .");
        }
    }

    @FXML
    private RadioButton in_house_radio_button;

    @FXML
    private RadioButton outsourced_radio_button;

    @FXML
    private TextField part_id_name_text;

    @FXML
    private TextField part_id_text;

    @FXML
    private TextField part_inventory_text;

    @FXML
    private TextField part_max_text;

    @FXML
    private TextField part_min_text;

    @FXML
    private TextField part_name_text;

    @FXML
    private TextField part_price_text;

    @FXML
    private Label part_type_name_label;

    /**
     * Cancel button. Returns to the Main Stage
     *
     * @param event the event
     * @throws IOException the io exception
     */
    @FXML
    void cancel_button(ActionEvent event) throws IOException {
        MainController.selected_part = null;
        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        SceneHelper.changeScene(stage, "/views/main_menu.fxml");
    }

    /**
     * In house radio button action.
     *
     * @param event the event
     */
    @FXML
    void in_house_radio_button_action(ActionEvent event) {
        outsourced_radio_button.setSelected(false);
        part_type_name_label.setText("Machine ID");
    }

    /**
     * Outsourced radio button action.
     *
     * @param event the event
     */
    @FXML
    void outsourced_radio_button_action(ActionEvent event) {
        in_house_radio_button.setSelected(false);
        part_type_name_label.setText("Company Name");
    }

    /**
     * Saves a new part to inventory.
     * <p>
     * Text fields are validated with error messages displayed preventing empty and/or
     * invalid values.
     *
     * @param event Save button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void save_button_action(ActionEvent event) throws IOException {
        boolean valid = true;

        try {
            int id = 0;
            if (!part_id_text.getText().isEmpty()) {
                id = Integer.parseInt(part_id_text.getText());
            }

            String name = part_name_text.getText();
            String specialId = part_id_name_text.getText();
            double price = Double.parseDouble(part_price_text.getText());
            int max = Integer.parseInt(part_max_text.getText());
            int min = Integer.parseInt(part_min_text.getText());
            int stock = Integer.parseInt(part_inventory_text.getText());

            // Validate Fields
            if (Validators.fieldIsEmpty(name)) {
                valid = false;
                SceneHelper.display_alert("Error", "Part Name cannot be empty");
            }

            if (Validators.minNotValid(min, max)) {
                valid = false;
                SceneHelper.display_alert("Error", "Min is either missing or greater than the max");
            }

            if (Validators.inventoryNotValid(stock, min, max)) {
                valid = false;
                SceneHelper.display_alert("Error", "Inventory count is invalid");
            }

            if (!(in_house_radio_button.isSelected() || outsourced_radio_button.isSelected())) {
                valid = false;
                SceneHelper.display_alert("Error", "Part Type must be selected");
            }

            if (id == 0 && valid) {
                System.out.println("Creating...");
                id = Inventory.get_next_part_id();
                if (in_house_radio_button.isSelected()) {
                    try {
                        int machineId = Integer.parseInt(specialId);
                        if (!Validators.fieldIsEmpty(machineId)) {
                            valid = false;
                            SceneHelper.display_alert("Error", "Machine ID is missing or unknown");
                        }
                        InHouse new_in_house_part = new InHouse(id, name, price, stock, min, max, machineId);

                        Inventory.addPart(new_in_house_part);
                    } catch (Exception e) {
                        SceneHelper.display_alert("Error", "unknown error");
                    }
                }
                if (outsourced_radio_button.isSelected()) {
                    try {
                        Outsourced new_outsourced_part = new Outsourced(id, name, price, stock, min, max, specialId);
                        Inventory.addPart(new_outsourced_part);
                    } catch (Exception e) {
                        SceneHelper.display_alert("Error", "unknown error");
                    }
                }
            }

            if (id != 0 && valid) {
                System.out.println("Updating...");
                Part updated_part = Inventory.lookupPart(id);
                assert updated_part != null;
                updated_part.setName(name);
                updated_part.setPrice(price);
                updated_part.setStock(stock);
                updated_part.setMin(min);
                updated_part.setMax(max);
                if (in_house_radio_button.isSelected()) {
                    try {
                        int machineId = Integer.parseInt(specialId);
                        InHouse new_in_house_part = new InHouse(updated_part.getId(),
                                updated_part.getName(),
                                updated_part.getPrice(),
                                updated_part.getStock(),
                                updated_part.getMin(),
                                updated_part.getMax(),
                                machineId
                                );
                        Inventory.deletePart(updated_part);
                        Inventory.addPart(new_in_house_part);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        SceneHelper.display_alert("Error", "Error setting the MachineID, it must be an Integer");
                    }
                } else {
                    try {
                        Outsourced new_outsourced_part = new Outsourced(updated_part.getId(),
                                updated_part.getName(),
                                updated_part.getPrice(),
                                updated_part.getStock(),
                                updated_part.getMin(),
                                updated_part.getMax(),
                                specialId
                        );
                        Inventory.deletePart(updated_part);
                        Inventory.addPart(new_outsourced_part);
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                        SceneHelper.display_alert("Error", "Error setting the CompanyName");
                    }
                }
            }

            if (valid) {
                SceneHelper.returnToMainScene(event);
            }
        } catch (Exception e) {
            SceneHelper.display_alert("Error", "Looks like one or more fields may be empty. Please check the form, and try again");
        }
    }
}