package controllers;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import models.Inventory;
import models.Part;
import models.Product;
import models.validators.Validators;
import utilities.SceneHelper;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

/**
 * The type Products controller. Products Controller handles all Product actions.
 */
public class ProductsController implements Initializable {

    @Override
    public void initialize(URL location, ResourceBundle resourceBundle) {
        Product selected_product = MainController.selected_product;
        available_parts = Inventory.getAllParts();

        if (!Objects.isNull(selected_product)) {
            added_parts = selected_product.getAllAssociatedParts();

            for (Part part : added_parts) {
                available_parts.remove(part);
            }

            product_id_text.setText(Integer.toString(selected_product.getId()));
            product_name_text.setText(selected_product.getName());
            product_price_text.setText(Double.toString(selected_product.getPrice()));
            product_inventory_text.setText(Integer.toString(selected_product.getStock()));
            product_min_text.setText(Integer.toString(selected_product.getMin()));
            product_max_text.setText(Integer.toString(selected_product.getMax()));

        }

        part_table_view.setItems(available_parts);
        added_parts_table_view.setItems(added_parts);

        part_id_column.setCellValueFactory(new PropertyValueFactory<>("id"));
        part_name_column.setCellValueFactory(new PropertyValueFactory<>("name"));
        part_inventory_column.setCellValueFactory(new PropertyValueFactory<>("stock"));
        part_price_column.setCellValueFactory(new PropertyValueFactory<>("price"));

        added_part_id_column.setCellValueFactory(new PropertyValueFactory<>("id"));
        added_part_name_column.setCellValueFactory(new PropertyValueFactory<>("name"));
        added_part_inventory_column.setCellValueFactory(new PropertyValueFactory<>("stock"));
        added_part_price_column.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    @FXML
    private TableColumn<Part, Integer> added_part_id_column;

    @FXML
    private TableColumn<Part, Integer> added_part_inventory_column;

    @FXML
    private TableColumn<Part, Integer> added_part_name_column;

    @FXML
    private TableColumn<Part, Double> added_part_price_column;

    @FXML
    private TableView<Part> added_parts_table_view;

    @FXML
    private TableColumn<Part, Integer> part_id_column;

    @FXML
    private TableColumn<Part, Integer> part_inventory_column;

    @FXML
    private TableColumn<Part, String> part_name_column;

    @FXML
    private TableColumn<Part, Double> part_price_column;

    @FXML
    private TableView<Part> part_table_view;

    @FXML
    private TextField product_id_text;

    @FXML
    private TextField product_inventory_text;

    @FXML
    private TextField product_max_text;

    /**
     * The Product part search text.
     */
    @FXML
    TextField product_part_search_text;

    @FXML
    private Label product_min_label;

    @FXML
    private TextField product_min_text;

    @FXML
    private Label product_name_label;

    @FXML
    private TextField product_name_text;

    @FXML
    private Label product_price_label;

    @FXML
    private TextField product_price_text;

    @FXML
    private Button product_save;

    @FXML
    private Button remove_part_button;

    /**
     * The Selected part.
     */
    public Part selected_part = null;
    /**
     * The Available parts.
     */
    public ObservableList<Part> available_parts = FXCollections.observableArrayList();
    /**
     * The Added parts.
     */
    public ObservableList<Part> added_parts = FXCollections.observableArrayList();

    /**
     * Add part to product handler.
     *
     * @param event the event
     */
    @FXML
    void add_part_to_product_handler(ActionEvent event) {
        selected_part = part_table_view.getSelectionModel().getSelectedItem();

        if (Objects.isNull(selected_part)) {
            SceneHelper.display_alert("Error", "Please select a part to add.");
        } else {
            available_parts.remove(selected_part);
            added_parts.add(selected_part);
        }
    }

    /**
     * Cancel button handler.
     *
     * @param event the event
     * @throws IOException the io exception
     */
    @FXML
    void cancel_button_handler(ActionEvent event) throws IOException {
        MainController.selected_product = null;
        SceneHelper.returnToMainScene(event);
    }


    /**
     * Prod save handler.
     *
     * @param event the event
     */
    @FXML
    void product_save_handler(ActionEvent event) {
        boolean valid = true;
        boolean success = true;

        try {
            int id = 0;
            if (!product_id_text.getText().isEmpty()) {
                id = Integer.parseInt(product_id_text.getText());
            }
            String name = product_name_text.getText();
            Integer inventory = Integer.parseInt(product_inventory_text.getText());
            Double price = Double.parseDouble(product_price_text.getText());
            Integer min = Integer.parseInt(product_min_text.getText());
            Integer max = Integer.parseInt(product_max_text.getText());

            // Validators
            if (Validators.fieldIsEmpty(name)) {
                valid = false;
                SceneHelper.display_alert("Error", "Product Name cannot be empty");
            }

            if (Validators.inventoryNotValid(inventory, min, max)) {
                valid = false;
                SceneHelper.display_alert("Error", "Inventory count is invalid");
            }

            if (Validators.minNotValid(min, max)) {
                valid = false;
                SceneHelper.display_alert("Error", "Min is invalid");
            }

            if (id == 0) {
                Product product = new Product(
                        added_parts, Inventory.get_next_product_id(),
                        name,
                        price,
                        inventory,
                        min,
                        max);
                Inventory.addProduct(product);
            } else {
                Product selected_product = Inventory.lookupProduct(id);
                selected_product.setName(name);
                selected_product.setPrice(price);
                selected_product.setStock(inventory);
                selected_product.setMin(min);
                selected_product.setMax(max);
                selected_product.setAssociatedParts(added_parts);
            }

            if (valid) {
                SceneHelper.returnToMainScene(event);
            }
        } catch (Exception e) {
            SceneHelper.display_alert("Error", "Program encountered an unknown error");
        }
    }

    /**
     * Remove part handler.
     *
     * @param event the event
     */
    @FXML
    void remove_part_handler(ActionEvent event) {
        selected_part = added_parts_table_view.getSelectionModel().getSelectedItem();

        // Example of correcting a runtime error by preventing null from being passed
        // to the Controller.
        if (Objects.isNull(selected_part)) {
            SceneHelper.display_alert("Error", "Please select a part to remove");
        } else {
            available_parts.add(selected_part);
            added_parts.remove(selected_part);
        }
    }

    private Product selected_product;

    @FXML
    private Button add_part_to_product_button;

    @FXML
    private Label add_product_label;
    @FXML
    private Label main_label;
    @FXML
    private Button product_cancel_button;
    @FXML
    private Label product_inventory_label;
    @FXML
    private Label product_id_label;
    @FXML
    private Label product_max_label;

    /**
     * Product part search handler.
     *
     * @param event the event
     */
    @FXML
    void product_part_search_handler(KeyEvent event) {
        String search_string = product_part_search_text.getText().toLowerCase();

        if (!Inventory.searchedParts.isEmpty()) {
            Inventory.searchedParts.clear();
        }

        for (Part part : Inventory.allParts) {
            if (String.valueOf(part.getId()).contains(search_string) || part.getName().toLowerCase().contains(search_string)) {
                Inventory.searchedParts.add(part);
            }
        }

        if (Inventory.searchedParts.isEmpty()) {
            System.out.println("No parts found, loading all parts");
            part_table_view.setItems(Inventory.allParts);
        } else {
            System.out.println("Parts Found!");
            part_table_view.setItems(Inventory.searchedParts);
        }
    }
}
