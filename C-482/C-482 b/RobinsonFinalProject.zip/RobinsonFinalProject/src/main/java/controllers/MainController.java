package controllers;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import models.Inventory;
import models.Part;
import models.Product;
import utilities.SceneHelper;

import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.Optional;
import java.util.ResourceBundle;

/**
 * The main controller of the application.
 */
public class MainController implements Initializable {

    /**
     * The Stage.
     */
    Stage stage;
    /**
     * The Scene.
     */
    Parent scene;

    /**
     * Needed to create an Initialized instance of the MainController - because the fonts were not working with my mac
     * TODO: Fix the fonts - The following fonts are added due to the odd behavior that Intellij uses when using the default system font.
     * Because default system fonts start with a 'dot' , such as .SNF, the UI does not render text accurately. Hence the monkey patch here.
     */
    @Override
    public void initialize(URL location, ResourceBundle resourceBundle) {
        main_pane.setStyle("-fx-font-family: 'sans-serif'");
        main_label.setStyle("-fx-font-family: 'sans-serif'");
        part_search_field.setStyle("-fx-font-family: 'sans-serif'");
        product_search_field.setStyle("-fx-font-family: 'sans-serif'");
        parts_label.setStyle("-fx-font-family: 'sans-serif'");
        products_label.setStyle("-fx-font-family: 'sans-serif'");


        part_table_view.setItems(Inventory.getAllParts());
        part_id_col.setCellValueFactory(new PropertyValueFactory<>("id"));
        part_name_col.setCellValueFactory(new PropertyValueFactory<>("name"));
        part_inventory_col.setCellValueFactory(new PropertyValueFactory<>("stock"));
        part_price_col.setCellValueFactory(new PropertyValueFactory<>("price"));

        product_table_view.setItems(Inventory.getAllProducts());

        product_id_col.setCellValueFactory(new PropertyValueFactory<>("id"));
        product_name_col.setCellValueFactory(new PropertyValueFactory<>("name"));
        product_inventory_col.setCellValueFactory(new PropertyValueFactory<>("stock"));
        product_price_col.setCellValueFactory(new PropertyValueFactory<>("price"));
    }

    @FXML
    private Label main_label;

    @FXML
    private Button part_modify_button;

    @FXML
    private Button product_add_button;

    @FXML
    private Button product_modify_button;

    @FXML
    private Button product_delete_button;

    @FXML
    private Button product_exit_button;

    @FXML
    private Label parts_label;

    @FXML
    private Label products_label;

    @FXML
    private AnchorPane main_pane;

    @FXML
    private Button part_add_button;

    @FXML
    private Button part_delete_button;

    @FXML
    private TableColumn<Part, Integer> part_id_col;

    @FXML
    private TableColumn<Part, Integer> part_inventory_col;

    @FXML
    private TableColumn<Part, String> part_name_col;

    @FXML
    private TableColumn<Part, Double> part_price_col;

    @FXML
    private TextField part_search_field;

    @FXML
    private TableView<Part> part_table_view;

    @FXML
    private TableView<Product> product_table_view;

    @FXML
    private TableColumn<Product, Integer> product_id_col;

    @FXML
    private TableColumn<Product, Integer> product_inventory_col;

    @FXML
    private TableColumn<Product, String> product_name_col;

    @FXML
    private TableColumn<Product, Double> product_price_col;

    @FXML
    private TextField product_search_field;


    /**
     * The constant selected_part.
     */
    public static Part selected_part = null;
    /**
     * The constant selected_product.
     */
    public static Product selected_product = null;

    /**
     * Update part handler.
     *
     * @param event the event
     * @throws IOException the io exception
     */
    @FXML
    void update_part_handler(ActionEvent event) throws IOException {
        selected_part = part_table_view.getSelectionModel().getSelectedItem();

        // Example of correcting a runtime error by preventing null from being passed
        // to the Controller.
        if (Objects.isNull(selected_part)) {
            SceneHelper.display_alert("Error", "Please select a part to modify.");
        } else {
            Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/parts/_form.fxml")));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Update product handler.
     *
     * @param event the event
     * @throws IOException the io exception
     */
    @FXML
    void update_product_handler(ActionEvent event) throws IOException {

        selected_product = product_table_view.getSelectionModel().getSelectedItem();

        // Example of correcting a runtime error by preventing null from being passed
        // to the Controller.
        if (Objects.isNull(selected_product)) {
            SceneHelper.display_alert("Error", "Please select a product to modify.");
        } else {
            Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/products/_form.fxml")));
            Scene scene = new Scene(parent);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.show();
        }
    }

    /**
     * Part to update part.
     *
     * @return the part
     */
    public static Part part_to_update() {
        return selected_part;
    }

    /**
     * Part delete handler.
     *
     * @param event the event
     * @throws IOException the io exception
     */
    @FXML
    void part_delete_handler(ActionEvent event) throws IOException {
        selected_part = part_table_view.getSelectionModel().getSelectedItem();

        if (Objects.isNull(selected_part)) {
            SceneHelper.display_alert("Error", "Please select a part to modify.");
        } else {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Alert: You are about to delete this");
            alert.setContentText("Do you want to delete the selected part?");
            alert.getDialogPane().setStyle("-fx-font-family: 'sans-serif'");

            Optional<ButtonType> result = alert.showAndWait();

            if (result.isPresent() && result.get() == ButtonType.OK) {
                Inventory.deletePart(selected_part);
                selected_part = null;
            }
        }
    }

    /**
     * Product add handler.
     *
     * @param event the event
     * @throws IOException the io exception
     */
    @FXML
    void product_add_handler(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/products/_form.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Loads the CreatePartsController.
     *
     * @param event Add button action.
     * @throws IOException From FXMLLoader.
     */
    @FXML
    void part_add_handler(ActionEvent event) throws IOException {
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("/views/parts/_form.fxml")));
        Scene scene = new Scene(parent);
        Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        stage.setScene(scene);
        stage.show();
    }



    /**
     * Product delete handler.
     *
     * @param event the event
     */
    @FXML
    void product_delete_handler(ActionEvent event) {
        selected_product = product_table_view.getSelectionModel().getSelectedItem();

        if (Objects.isNull(selected_product)) {
            SceneHelper.display_alert("Error", "Please select a product to modify.");
        } else {
            // Check if product has any associated parts with it.
            if (selected_product.getAllAssociatedParts().size() > 0) {
                SceneHelper.display_alert("Error", "You cannot delete a product that has associated parts.");

            } else {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Alert: You are about to delete this");
                alert.setContentText("Do you want to delete the selected product?");
                alert.getDialogPane().setStyle("-fx-font-family: 'sans-serif'");

                Optional<ButtonType> result = alert.showAndWait();

                if (result.isPresent() && result.get() == ButtonType.OK) {
                    Inventory.deleteProduct(selected_product);
                    selected_product = null;
                }
            }
        }
    }

    /**
     * Part search handler.
     *
     * @param event the event
     */
    @FXML
    void part_search_handler(KeyEvent event) {
        System.out.println("Searching ...");
        String search_string = part_search_field.getText().toLowerCase();

        if (!Inventory.searchedParts.isEmpty()) {
            Inventory.searchedParts.clear();
        }

        for (Part part : Inventory.allParts) {
            if (String.valueOf(part.getId()).contains(search_string) || part.getName().toLowerCase().contains(search_string)) {
                Inventory.searchedParts.add(part);
            }
        }

        if (Inventory.searchedParts.isEmpty()) {
            part_table_view.getItems().clear();
        } else {
            part_table_view.setItems(Inventory.searchedParts);
        }
    }

    /**
     * Product search handler.
     *
     * @param event the event
     */
    @FXML
    void product_search_handler(KeyEvent event) {
        String search_string = product_search_field.getText().toLowerCase();

        if (!Inventory.searchedProducts.isEmpty()) {
            Inventory.searchedProducts.clear();
        }

        for (Product product : Inventory.allProducts) {
            if (String.valueOf(product.getId()).contains(search_string) || product.getName().toLowerCase().contains(search_string)) {
                System.out.println("Found");
                Inventory.searchedProducts.add(product);
            }
        }

        if (Inventory.searchedProducts.isEmpty()) {
            product_table_view.getItems().clear();
        } else {
            product_table_view.setItems(Inventory.searchedProducts);
        }
    }


    /**
     * Exit button handler.
     *
     * @param event the event
     * @throws IOException the io exception
     */
    @FXML
    void exit_button_handler(ActionEvent event) throws IOException {

        System.exit(0);
    }
}