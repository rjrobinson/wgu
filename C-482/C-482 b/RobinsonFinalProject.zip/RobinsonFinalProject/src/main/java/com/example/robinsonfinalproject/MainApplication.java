package com.example.robinsonfinalproject;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import models.Inventory;
import models.Part;
import models.Product;
import models.parts.InHouse;
import models.parts.Outsourced;

import java.io.IOException;


/**
 * The Main application.
 * Javadocs can be found at src/main/java/JavaDocs
 * Main Application is a Inventory Management System that allows the management of ( currently ) bike parts.
 * But can be adapted to any types of parts or products.
 * @author Robert J Robinson
 */
public class MainApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        initData();
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource("/views/main_menu.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1200, 500);
        scene.getRoot().setStyle("-fx-font-family: 'Arial'");
        scene.getStylesheets().add(getClass().getResource("/style/main.css").toExternalForm());
        stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     * FUTURE ENHANCEMENT - Connect the data to a RDBMS such as MySql later for more permanent storage.
     */
    public static void main(String[] args) {
        launch();
    }

    private void initData() {
        System.out.println("Initializing Inventory...");
        // initData initializes data for the application to load. FUTURE ENHANCEMENT: Wire this up to a database in the future.

        InHouse in_house_part_1 = new InHouse(1, "Handle", 100.00, 1, 1, 2, 1);
        InHouse in_house_part_2 = new InHouse(2, "Breaks", 200.00, 1, 1, 2, 1);
        InHouse in_house_part_3 = new InHouse(3, "Wheel", 300.00, 1, 1, 2, 1);
        InHouse in_house_part_4 = new InHouse(4, "Seat", 400.00, 1, 1, 2, 1);

        Outsourced outsourced_part_5 = new Outsourced(5, "Fork", 100.00, 1, 1, 10, "RockShock");
        Outsourced outsourced_part_6 = new Outsourced(6, "Pads", 200.00, 1, 1, 10, "Evil");
        Outsourced outsourced_part_7 = new Outsourced(7, "Spring", 300.00, 1, 1, 10, "Schwinn");
        Outsourced outsourced_part_8 = new Outsourced(8, "Carbon Fiber Frame", 400.00, 1, 1, 10, "Huffy");
        ObservableList<Part> product_parts_list = FXCollections.observableArrayList();

        Product product1 = new Product(product_parts_list, 1, "Bike", 1000.00, 1, 1, 10);

        // Add in sourced parts
        Inventory.addPart(in_house_part_1);
        Inventory.addPart(in_house_part_2);
        Inventory.addPart(in_house_part_3);
        Inventory.addPart(in_house_part_4);

        // Add outsourced parts
        Inventory.addPart(outsourced_part_5);
        Inventory.addPart(outsourced_part_6);
        Inventory.addPart(outsourced_part_7);
        Inventory.addPart(outsourced_part_8);

        // Add products
        product_parts_list.add(in_house_part_1);
        product_parts_list.add(in_house_part_2);
        Inventory.addProduct(product1);
    }
}