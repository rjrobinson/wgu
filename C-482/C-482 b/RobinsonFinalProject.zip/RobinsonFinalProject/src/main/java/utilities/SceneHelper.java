package utilities;

import com.example.robinsonfinalproject.MainApplication;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

/**
 * The type Scene helper.
 *
 * @author RJ Robinson
 */
public class SceneHelper {

    /**
     * Return to main scene.
     *
     * @param event the event
     * @throws IOException the io exception
     */
    public static void returnToMainScene(ActionEvent event) throws IOException {

        Stage stage = (Stage) ((Button) event.getSource()).getScene().getWindow();
        SceneHelper.changeScene(stage, "/views/main_menu.fxml");
    }

    /**
     * Change scene.
     *
     * @param stage      the stage
     * @param scene_path the scene path
     * @throws IOException the io exception
     */
    public static void changeScene(Stage stage, String scene_path) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(MainApplication.class.getResource(scene_path));
        Scene scene = new Scene(fxmlLoader.load(), 1200, 600);
        scene.getRoot().setStyle("-fx-font-family: 'Arial'");

        stage.setTitle("Inventory Management System");
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Display alert.
     *
     * @param alert_title the alert title
     * @param message     the message
     */
    public static void display_alert(String alert_title, String message) {
        System.out.println(message);
        if (alert_title.equals("Error")) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle(alert_title);
            alert.setHeaderText(alert_title);
            alert.setContentText(message);
            alert.getDialogPane().setStyle("-fx-font-family: 'Arial'");
            alert.showAndWait();
        }

        if (alert_title.equals("Warning")) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle(alert_title);
            alert.setHeaderText(alert_title);
            alert.setContentText(message);
            alert.getDialogPane().setStyle("-fx-font-family: 'Arial'");
            alert.showAndWait();
        }
    }
}