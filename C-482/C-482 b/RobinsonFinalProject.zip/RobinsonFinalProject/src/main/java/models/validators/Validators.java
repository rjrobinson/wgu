package models.validators;

/**
 * The Validators used to ensure trhat fields are present and return proper messages.
 * @author RJ Robinson
 */
public class Validators {
    private static boolean isBetween(int value, int min, int max) {
        return value >= min && value <= max;
    }

    /**
     * Inventory not valid boolean.
     *
     * @param value the value
     * @param min   the min
     * @param max   the max
     * @return the boolean
     */
    public static boolean inventoryNotValid(int value, int min, int max) {
        return !isBetween(value, min, max);
    }

    /**
     * Min not valid boolean.
     *
     * @param min the min
     * @param max the max
     * @return the boolean
     */
    public static boolean minNotValid(int min, int max) {
        return min < 0 || min > max;
    }

    /**
     * Field is empty boolean.
     *
     * @param value the value
     * @return the boolean
     */
    public static boolean fieldIsEmpty(String value) {
        return value.isEmpty();
    }

    /**
     * Field is empty boolean.
     *
     * @param value the value
     * @return the boolean
     */
    public static boolean fieldIsEmpty(int value) {
        return value >= 0 ;
    }
}
