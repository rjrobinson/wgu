package models;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.util.Objects;

/**
 * The type Inventory.
 */
public class Inventory {

    /**
     * The All parts.
     */
    public static final ObservableList<Part> allParts = FXCollections.observableArrayList();
    /**
     * The constant searchedParts.
     */
    public static final ObservableList<Part> searchedParts = FXCollections.observableArrayList();
    /**
     * The All products.
     */
    public static final ObservableList<Product> allProducts = FXCollections.observableArrayList();
    /**
     * The constant searchedProducts.
     */
    public static final ObservableList<Product> searchedProducts = FXCollections.observableArrayList();


    /**
     * Add part.
     *
     * @param part the part
     */
    public static void addPart(Part part) {
        allParts.add(part);
    }

    /**
     * Add product.
     *
     * @param product the product
     */
    public static void addProduct(Product product) {
        allProducts.add(product);
    }

    /**
     * Lookup part.
     *
     * @param partID the part id
     * @return part part
     */
    public static Part lookupPart(int partID) {

        for (Part part : allParts) {
            if (part.getId() == partID) {
                return part;
            }
        }
        return null;
    }

    /**
     * Lookup product.
     *
     * @param productID the product id
     * @return the product
     */
    public static Product lookupProduct(int productID) {
        for (Product product : allProducts) {
            if (product.getId() == productID) {
                return product;
            }
        }
        return null;
    }

    /**
     * Delete product.
     *
     * @param selected_product the selected product
     */
    public static void deleteProduct(Product selected_product) {
        allProducts.remove(selected_product);
    }

    /**
     * Lookup part.
     *
     * @param partName the part name
     */
//    Look up by names
    public void lookupPart(String partName) {
        for (Part part : allParts) {
            if (Objects.equals(part.getName(), partName)) {
                System.out.println(part);
            }
        }
    }

    /**
     * Lookup product.
     *
     * @param productName the product name
     */
    public void lookupProduct(String productName) {
        for (Product product : allProducts) {
            if (Objects.equals(product.getName(), productName)) {
                System.out.println(product);
            }
        }
    }


    /**
     * Update part.
     *
     * @param partID       the part id
     * @param selectedPart the selected part
     * @author RJ Robinson
     */
    public static void updatePart(int partID, Part selectedPart) {
        for (Part part : allParts) {
            if (part.getId() == partID) {
                part.setName(selectedPart.getName());
                part.setStock(selectedPart.getStock());
                part.setPrice(selectedPart.getPrice());
                part.setMax(selectedPart.getMax());
                part.setMin(selectedPart.getMin());
            }
        }
    }

    /**
     * Update product.
     *
     * @param productID       the product id
     * @param selectedProduct the selected product
     */
    public void updateProduct(int productID, Part selectedProduct) {
        for (Product product : allProducts) {
            if (product.getId() == productID) {
                product.setName(selectedProduct.getName());
                product.setStock(selectedProduct.getStock());
                product.setPrice(selectedProduct.getPrice());
                product.setMax(selectedProduct.getMax());
                product.setMin(selectedProduct.getMin());
            }
        }
    }

    /**
     * Delete part.
     *
     * @param part the part
     */
    public static void deletePart(Part part) {
        allParts.remove(part);
    }

    /**
     * Delete product.
     *
     * @param selectedProduct the selected product
     */
    public void deleteProduct(Part selectedProduct) {
        //     Do things
    }

    /**
     * Gets all parts.
     *
     * @return the all parts
     */
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    /**
     * Gets next part id.
     *
     * @return the next part id
     */
    public static int get_next_part_id() {
        int next_part_id = 0;
        for (Part part : allParts) {
            if (part.getId() > next_part_id) {
                next_part_id = part.getId();
            }
        }
        return next_part_id + 1;
    }

    /**
     * Gets next product id.
     *
     * @return the next product id
     */
    public static int get_next_product_id() {
        int next_product_id = 0;
        for (Product product : allProducts) {
            if (product.getId() > next_product_id) {
                next_product_id = product.getId();
            }
        }
        return next_product_id + 1;
    }

    /**
     * Gets all products.
     *
     * @return the all products
     */
    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }
}
