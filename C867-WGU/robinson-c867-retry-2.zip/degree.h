#ifndef DEGREEPROGRAM_H
#define DEGREEPROGRAM_H

enum DegreeProgram {
    NETWORK,
    SECURITY,
    SOFTWARE,
    UNDEFINED_PROGRAM
};



#endif